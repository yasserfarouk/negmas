History
=======

Release 0.1.3
-------------
* removing some unnecessary dependencies that may cause compilation issues

Release 0.1.2
-------------
* First public release
